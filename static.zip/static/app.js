const form=document.querySelector('#form');
const text=(tag,value)=>{const el=document.createElement(tag);el.textContent=value;return el;};
function renderTable(data){
  const t=document.querySelector('#punnett');t.replaceChildren();
  const head=document.createElement('tr');const corner=text('th','×');corner.className='corner';head.append(corner);
  for(const g of data.gametes[1])head.append(text('th',g));t.append(head);
  data.table.forEach((row,i)=>{const tr=document.createElement('tr');tr.append(text('th',data.gametes[0][i]));row.forEach(g=>tr.append(text('td',g)));t.append(tr);});
  document.querySelector('#combinations').textContent=`${data.total} kombinací`;
}
function renderBars(id,values){
 const el=document.getElementById(id);el.replaceChildren();
 for(const item of values){const box=document.createElement('div'),line=document.createElement('div'),fill=document.createElement('div'),track=document.createElement('div');line.className='bar-heading';line.append(text('strong',item.label),text('span',`${item.percent} % · ${item.fraction}`));track.className='track';fill.className='fill';fill.style.width=`${item.percent}%`;track.append(fill);box.append(line,track);el.append(box);}
}
async function calculate(){document.querySelector('#error').textContent='';try{const response=await fetch('/api/cross',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({parent1:document.querySelector('#p1').value,parent2:document.querySelector('#p2').value})});const data=await response.json();if(!response.ok)throw Error(data.error||'Chyba');renderTable(data);renderBars('genotypes',data.genotypes);renderBars('phenotypes',data.phenotypes);}catch(error){document.querySelector('#error').textContent=error.message;}}
form.addEventListener('submit',e=>{e.preventDefault();calculate();});document.querySelectorAll('[data-a]').forEach(b=>b.addEventListener('click',()=>{document.querySelector('#p1').value=b.dataset.a;document.querySelector('#p2').value=b.dataset.b;calculate();}));calculate();
