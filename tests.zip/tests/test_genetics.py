import unittest
from genetics import gametes, make_cross, parse_genotype


class GeneticsTests(unittest.TestCase):
    def test_single_gene_ratio(self):
        result = make_cross("Aa", "Aa")
        self.assertEqual(result["total"], 4)
        self.assertEqual({x["label"]: x["count"] for x in result["genotypes"]},
                         {"AA": 1, "Aa": 2, "aa": 1})
        self.assertEqual(sorted(x["count"] for x in result["phenotypes"]), [1, 3])

    def test_dihybrid_distribution(self):
        result = make_cross("Aa Bb", "Aa Bb")
        self.assertEqual(result["total"], 16)
        self.assertEqual(sorted((x["count"] for x in result["phenotypes"])), [1, 3, 3, 9])

    def test_homozygote(self):
        self.assertEqual(set(gametes(parse_genotype("AA bb"))), {"Ab"})

    def test_validation(self):
        for bad in ("ABC", "Aa Aa", "A1", "Aa Bb Cc", "Ax"):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                parse_genotype(bad)
        with self.assertRaises(ValueError):
            make_cross("Aa Bb", "Aa Cc")


if __name__ == "__main__":
    unittest.main()
